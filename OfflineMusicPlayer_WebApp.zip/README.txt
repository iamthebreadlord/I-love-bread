
Offline Music Player browser prototype.

How to use:
1. Upload these files to a web host or GitHub Pages.
2. Open in your Fire tablet browser.
3. It can later be turned into a PWA app.

This version is the UI prototype.
